import React, { useState } from 'react';

const Contact: React.FC = () => {
    const [contactName, setContactName] = useState('');
    const [contactEmail, setContactEmail] = useState('');
    const [contactMessage, setContactMessage] = useState('');

    const handleContactSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        
        const recipient = 'elsintdm@gmail.com';
        const subject = `Kontakt poruka sa sajta od: ${contactName}`;
        const body = `
Ime i Prezime: ${contactName}
Email: ${contactEmail}

Poruka:
${contactMessage}
        `;

        window.location.href = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body.trim())}`;

        // Reset form after submission
        setContactName('');
        setContactEmail('');
        setContactMessage('');
    };

    return (
        <section id="contact" className="py-20 bg-white">
            <div className="container mx-auto px-4 max-w-4xl">
                <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-montserrat text-blue-600">Kontaktirajte Nas</h2>
                <div className="grid md:grid-cols-2 gap-12">
                    <div>
                        <p className="text-lg text-gray-700 mb-6">Imate pitanje ili želite da zakažete servis? Stojimo vam na raspolaganju!</p>
                        <div className="space-y-4 text-lg">
                            <p><i className="fas fa-map-marker-alt text-blue-500 w-6"></i> Adresa: Bulevar Oslobodjenja 43, 21000 Novi Sad, Srbija</p>
                            <p><i className="fas fa-phone text-blue-500 w-6"></i> Telefon: +381 653755223</p>
                            <p><i className="fas fa-envelope text-blue-500 w-6"></i> Email: elsintdm@gmail.com</p>
                            <p><i className="fas fa-clock text-blue-500 w-6"></i> Radno vreme: Pon-Pet: 09:00 - 17:00</p>
                        </div>
                    </div>
                    <form className="space-y-4" onSubmit={handleContactSubmit}>
                        <div>
                            <label htmlFor="contact-name" className="block text-sm font-medium text-gray-700">Ime i Prezime</label>
                            <input 
                                type="text" 
                                id="contact-name" 
                                value={contactName}
                                onChange={(e) => setContactName(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            />
                        </div>
                        <div>
                            <label htmlFor="contact-email" className="block text-sm font-medium text-gray-700">Email Adresa</label>
                            <input 
                                type="email" 
                                id="contact-email" 
                                value={contactEmail}
                                onChange={(e) => setContactEmail(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            />
                        </div>
                        <div>
                            <label htmlFor="contact-message" className="block text-sm font-medium text-gray-700">Vaša Poruka</label>
                            <textarea 
                                id="contact-message" 
                                rows={4} 
                                value={contactMessage}
                                onChange={(e) => setContactMessage(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            ></textarea>
                        </div>
                        <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-300 shadow-md">Pošalji Poruku</button>
                    </form>
                </div>
            </div>
        </section>
    );
};

export default Contact;
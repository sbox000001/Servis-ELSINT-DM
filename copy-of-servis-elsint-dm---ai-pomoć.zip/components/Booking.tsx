import React, { useState, useEffect } from 'react';

interface BookingProps {
    problemSummary: string;
    onBackToDiagnostics: () => void;
}

type BookingType = 'phone' | 'visit';

const Booking: React.FC<BookingProps> = ({ problemSummary, onBackToDiagnostics }) => {
    const [bookingType, setBookingType] = useState<BookingType>('phone');
    const [summary, setSummary] = useState(problemSummary);
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        date: '',
        time: '',
        address: '',
    });

    useEffect(() => {
        setSummary(problemSummary);
    }, [problemSummary]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        
        const recipient = 'elsintdm@gmail.com';
        const subject = bookingType === 'phone'
            ? `Zahtev za Telefonski Poziv - ${formData.name}`
            : `Zahtev za Dolazak na Adresu - ${formData.name}`;

        const bodyParts = [
            bookingType === 'phone' ? 'Novi zahtev za telefonski poziv:' : 'Novi zahtev za dolazak na adresu:',
            '--------------------------------',
            `Korisnik: ${formData.name}`,
            `Telefon: ${formData.phone}`,
            `Email: ${formData.email || 'Nije naveden'}`,
            `Datum: ${formData.date}`,
            `Vreme: ${formData.time}`,
        ];

        if (bookingType === 'visit' && formData.address) {
            bodyParts.push(`Adresa: ${formData.address}`);
        }

        bodyParts.push('--------------------------------');
        bodyParts.push(`\nOpis problema:\n${summary}`);

        const body = encodeURIComponent(bodyParts.join('\n'));
        
        window.location.href = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${body}`;

        // Reset form after submission
        setFormData({ name: '', phone: '', email: '', date: '', time: '', address: '' });
    };

    const commonFormFields = (
        <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor={`${bookingType}-name`} className="block text-sm font-medium text-gray-700">Ime i Prezime</label>
                    <input type="text" id={`${bookingType}-name`} name="name" value={formData.name} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                </div>
                <div>
                    <label htmlFor={`${bookingType}-phone`} className="block text-sm font-medium text-gray-700">Broj Telefona</label>
                    <input type="tel" id={`${bookingType}-phone`} name="phone" value={formData.phone} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                </div>
            </div>
            <div>
                <label htmlFor={`${bookingType}-email`} className="block text-sm font-medium text-gray-700">Email Adresa (opciono)</label>
                <input type="email" id={`${bookingType}-email`} name="email" value={formData.email} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor={`${bookingType}-date`} className="block text-sm font-medium text-gray-700">Preferirani Datum</label>
                    <input type="date" id={`${bookingType}-date`} name="date" value={formData.date} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                </div>
                <div>
                    <label htmlFor={`${bookingType}-time`} className="block text-sm font-medium text-gray-700">Preferirano Vreme</label>
                    <select id={`${bookingType}-time`} name="time" value={formData.time} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        <option value="">Odaberite vreme</option>
                        {bookingType === 'phone' ? (
                            <>
                                <option>09:00 - 10:00</option>
                                <option>10:00 - 11:00</option>
                                <option>11:00 - 12:00</option>
                                <option>12:00 - 13:00</option>
                                <option>13:00 - 14:00</option>
                                <option>14:00 - 15:00</option>
                                <option>15:00 - 16:00</option>
                                <option>16:00 - 17:00</option>
                            </>
                        ) : (
                            <>
                                <option>09:00 - 11:00</option>
                                <option>11:00 - 13:00</option>
                                <option>13:00 - 15:00</option>
                                <option>15:00 - 17:00</option>
                            </>
                        )}
                    </select>
                </div>
            </div>
            <div>
                <label htmlFor={`${bookingType}-problem-summary`} className="block text-sm font-medium text-gray-700">Kratak opis problema</label>
                <textarea 
                    id={`${bookingType}-problem-summary`} 
                    name="summary"
                    rows={4} 
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                ></textarea>
            </div>
        </>
    );

    return (
        <section className="py-12 md:py-20">
            <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8 md:p-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 font-montserrat text-blue-600">Zakažite Stručnu Pomoć</h2>
                    
                    <div className="flex justify-center border border-gray-300 rounded-lg p-1 mb-8 bg-gray-100">
                        <button 
                            onClick={() => setBookingType('phone')}
                            className={`w-1/2 py-2 px-4 rounded-md font-semibold transition ${bookingType === 'phone' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 hover:bg-gray-200'}`}
                        >
                            Telefonski Poziv
                        </button>
                        <button 
                            onClick={() => setBookingType('visit')}
                            className={`w-1/2 py-2 px-4 rounded-md font-semibold transition ${bookingType === 'visit' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 hover:bg-gray-200'}`}
                        >
                            Dolazak na Adresu
                        </button>
                    </div>

                    {bookingType === 'phone' && (
                        <form id="phone-call-form" onSubmit={handleSubmit} className="space-y-6">
                            <h3 className="text-xl font-semibold text-center text-gray-800">Zahtev za Telefonski Poziv</h3>
                            {commonFormFields}
                            <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-300 shadow-md">Pošalji Zahtev za Poziv</button>
                        </form>
                    )}

                    {bookingType === 'visit' && (
                        <form id="address-visit-form" onSubmit={handleSubmit} className="space-y-6">
                            <h3 className="text-xl font-semibold text-center text-gray-800">Zahtev za Dolazak na Adresu</h3>
                            {commonFormFields}
                             <div>
                                <label htmlFor="visit-address" className="block text-sm font-medium text-gray-700">Adresa</label>
                                <input type="text" id="visit-address" name="address" value={formData.address} onChange={handleInputChange} placeholder="Ulica i broj, Grad" required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-300 shadow-md">Pošalji Zahtev za Dolazak</button>
                        </form>
                    )}
                    
                    <div className="mt-8 flex justify-center">
                        <button onClick={onBackToDiagnostics} className="bg-gray-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-gray-600 transition duration-300">
                           Nazad na Dijagnostiku
                        </button>
                    </div>

                </div>
            </div>
        </section>
    );
};

export default Booking;
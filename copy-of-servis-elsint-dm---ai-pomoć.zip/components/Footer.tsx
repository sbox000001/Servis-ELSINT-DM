import React from 'react';
import type { View } from '../App';

interface FooterProps {
    onNavigate: (view: View) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
    return (
        <footer className="bg-gray-900 text-white py-10 mt-auto">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
                    <div>
                        <h3 
                            className="text-xl font-bold font-montserrat text-blue-500 mb-4 cursor-pointer inline-block"
                            onClick={() => onNavigate('homepage')}
                        >
                            <i className="fas fa-microchip text-green-400 mr-2"></i>
                            Servis ELSINT DM
                        </h3>
                        <p className="text-gray-400">Vaš pouzdan partner za servis elektronskih uređaja. Brzo, efikasno i uz pomoć AI tehnologije.</p>
                    </div>
                    <div>
                        <h3 className="font-semibold text-lg mb-4">Brzi Linkovi</h3>
                        <ul className="space-y-2">
                            <li><a href="#" onClick={(e) => { e.preventDefault(); onNavigate('homepage'); }} className="text-gray-400 hover:text-white transition">Početna</a></li>
                            <li><a href="#" onClick={(e) => { e.preventDefault(); onNavigate('services'); }} className="text-gray-400 hover:text-white transition">Usluge</a></li>
                            <li><a href="#" onClick={(e) => { e.preventDefault(); onNavigate('contact'); }} className="text-gray-400 hover:text-white transition">Kontakt</a></li>
                            <li><a href="#" onClick={(e) => { e.preventDefault(); onNavigate('diagnostics'); }} className="text-gray-400 hover:text-white transition">AI Asistent</a></li>
                        </ul>
                    </div>
                    <div>
                        <h3 className="font-semibold text-lg mb-4">Pratite Nas</h3>
                        <div className="flex justify-center md:justify-start space-x-6">
                            <a href="#" aria-label="Facebook" className="text-gray-400 hover:text-white transition text-2xl"><i className="fab fa-facebook-f"></i></a>
                            <a href="#" aria-label="Instagram" className="text-gray-400 hover:text-white transition text-2xl"><i className="fab fa-instagram"></i></a>
                            <a href="#" aria-label="Twitter" className="text-gray-400 hover:text-white transition text-2xl"><i className="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
                <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-500">
                    <p>&copy; {new Date().getFullYear()} Servis ELSINT DM. Sva prava zadržana.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
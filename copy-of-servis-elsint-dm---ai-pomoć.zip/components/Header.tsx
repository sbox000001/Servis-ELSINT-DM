import React from 'react';
import type { View } from '../App';

interface HeaderProps {
    onNavigate: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
    
    return (
        <header className="bg-white shadow-md sticky top-0 z-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-20">
                    <div 
                        className="flex-shrink-0 cursor-pointer" 
                        onClick={() => onNavigate('homepage')}
                    >
                        <h1 className="text-2xl md:text-3xl font-bold font-montserrat text-blue-600">
                            <i className="fas fa-microchip text-green-500 mr-2"></i>
                            Servis ELSINT DM
                        </h1>
                    </div>
                    <nav className="hidden md:flex md:space-x-8">
                        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('homepage'); }} className="text-gray-600 hover:text-blue-600 font-semibold transition duration-300">Početna</a>
                        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('services'); }} className="text-gray-600 hover:text-blue-600 font-semibold transition duration-300">Usluge</a>
                        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('contact'); }} className="text-gray-600 hover:text-blue-600 font-semibold transition duration-300">Kontakt</a>
                        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('diagnostics'); }} className="text-blue-600 hover:text-blue-800 font-bold transition duration-300">Pomoć (AI Asistent)</a>
                    </nav>
                </div>
            </div>
        </header>
    );
};

export default Header;
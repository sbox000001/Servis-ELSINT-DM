
export type Device = 'laptop' | 'tv' | 'ac' | 'washing-machine' | 'network' | 'other' | null;

export interface Solution {
  title: string;
  steps: string[];
}
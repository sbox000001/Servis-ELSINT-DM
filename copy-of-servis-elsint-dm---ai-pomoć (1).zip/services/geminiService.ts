import type { Device, Solution } from '../types';

export const getDiagnosticSolutions = async (device: Device, problemDescription: string): Promise<Solution[]> => {
    try {
        console.log("Slanje zahteva našem serverless servisu na Vercel-u...");
        
        // Pozivamo našu Vercel funkciju koja bezbedno rukuje API ključem
        const response = await fetch('/api/get-solutions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ device, problemDescription }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Greška servera: ${response.statusText}`);
        }

        const solutions = await response.json();

        if (!Array.isArray(solutions) || solutions.some(s => !s.title || !s.steps)) {
            console.error("Odgovor servera nije u očekivanom formatu:", solutions);
            throw new Error("Server nije vratio očekivani format (niz rešenja).");
        }
        
        console.log("Primljena rešenja:", solutions);
        return solutions as Solution[];

    } catch (error: any) {
        console.error("Greška prilikom komunikacije sa našim servisom:", error);
        throw new Error(error.message || "Nismo uspeli da dobijemo dijagnostiku od AI asistenta. Molimo pokušajte ponovo kasnije.");
    }
};
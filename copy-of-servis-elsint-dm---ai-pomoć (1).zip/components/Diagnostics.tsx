
import React, { useState, useCallback } from 'react';
import { getDiagnosticSolutions } from '../services/geminiService';
import type { Device, Solution } from '../types';

interface DiagnosticsProps {
    onNeedFurtherHelp: (summary: string) => void;
}

const StepIndicator: React.FC<{ currentStep: number }> = ({ currentStep }) => {
    const steps = ['Uređaj', 'Opis', 'Rešenja'];
    return (
        <div className="flex justify-center items-center mb-8">
            {steps.map((step, index) => (
                <React.Fragment key={index}>
                    <div className="flex items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${index + 1 <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'}`}>
                            {index + 1}
                        </div>
                        <span className={`ml-2 font-semibold ${index + 1 <= currentStep ? 'text-blue-600' : 'text-gray-500'}`}>{step}</span>
                    </div>
                    {index < steps.length - 1 && <div className={`flex-auto h-1 mx-4 ${index + 1 < currentStep ? 'bg-blue-600' : 'bg-gray-300'}`}></div>}
                </React.Fragment>
            ))}
        </div>
    );
};

const DeviceCard: React.FC<{ icon: string; label: string; value: Device; onSelect: (device: Device) => void; selected: boolean }> = ({ icon, label, value, onSelect, selected }) => (
    <div
        onClick={() => onSelect(value)}
        className={`flex flex-col items-center justify-center p-6 w-40 h-40 border-2 rounded-xl cursor-pointer transition-all duration-300 shadow-sm hover:shadow-lg hover:-translate-y-1 ${selected ? 'bg-blue-600 text-white border-blue-700' : 'bg-white hover:bg-blue-50 border-gray-200'}`}
    >
        <i className={`fas ${icon} text-5xl mb-3 ${selected ? 'text-white' : 'text-blue-500'}`}></i>
        <span className="font-semibold text-center">{label}</span>
    </div>
);

const Diagnostics: React.FC<DiagnosticsProps> = ({ onNeedFurtherHelp }) => {
    const [step, setStep] = useState(1);
    const [selectedDevice, setSelectedDevice] = useState<Device>(null);
    const [problemDescription, setProblemDescription] = useState('');
    const [solutions, setSolutions] = useState<Solution[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const devices: { label: string; value: Device; icon: string }[] = [
        { label: 'Laptopi', value: 'laptop', icon: 'fa-laptop' },
        { label: 'Televizor', value: 'tv', icon: 'fa-tv' },
        { label: 'Klima Uređaj', value: 'ac', icon: 'fa-fan' },
        { label: 'Kućna Elektronika', value: 'washing-machine', icon: 'fa-blender-phone' },
        { label: 'Mrežna Oprema', value: 'network', icon: 'fa-wifi' },
        { label: 'Ostalo', value: 'other', icon: 'fa-question-circle' },
    ];

    const handleDeviceSelect = (device: Device) => {
        setSelectedDevice(device);
        setStep(2);
    };

    const handleAnalyze = useCallback(async () => {
        if (!selectedDevice || !problemDescription) return;
        setIsLoading(true);
        setError(null);
        setSolutions([]);
        try {
            const result = await getDiagnosticSolutions(selectedDevice, problemDescription);
            setSolutions(result);
            setStep(3);
        } catch (err: any) {
            setError(err.message || 'Došlo je do nepredviđene greške.');
        } finally {
            setIsLoading(false);
        }
    }, [selectedDevice, problemDescription]);

    const renderStepContent = () => {
        switch (step) {
            case 1:
                return (
                    <div className="text-center">
                        <h3 className="text-2xl font-bold mb-8">Koji uređaj ima problem?</h3>
                        <div className="flex flex-wrap justify-center gap-4 md:gap-6">
                            {devices.map(d => <DeviceCard key={d.value} {...d} onSelect={handleDeviceSelect} selected={selectedDevice === d.value} />)}
                        </div>
                    </div>
                );
            case 2:
                return (
                    <div className="text-center">
                        <h3 className="text-2xl font-bold mb-8">Detaljno opišite problem:</h3>
                        <textarea
                            value={problemDescription}
                            onChange={(e) => setProblemDescription(e.target.value)}
                            className="w-full max-w-2xl mx-auto p-4 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                            placeholder="Npr. 'Moj laptop se ne pali...', 'Klima ne hladi...'"
                            rows={6}
                        ></textarea>
                        <div className="mt-8 flex justify-center gap-4">
                            <button onClick={() => setStep(1)} className="bg-gray-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-gray-600 transition duration-300">Nazad</button>
                            <button onClick={handleAnalyze} disabled={!problemDescription || isLoading} className="bg-blue-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-blue-700 transition duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed">
                                {isLoading ? <><i className="fas fa-spinner fa-spin mr-2"></i>Analiziram...</> : 'Analiziraj i Predloži Rešenja'}
                            </button>
                        </div>
                    </div>
                );
            case 3:
                return (
                    <div>
                        <h3 className="text-2xl font-bold text-center mb-8">Predložena Rešenja:</h3>
                        {error && <div className="text-center text-red-500 bg-red-100 p-4 rounded-lg mb-4">{error}</div>}
                        <div id="solution-list" className="space-y-6">
                            {solutions.map((sol, index) => (
                                <div key={index} className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                                    <h4 className="text-xl font-bold text-blue-600 mb-3">{sol.title}</h4>
                                    <ul className="list-disc list-inside space-y-2 text-gray-700">
                                        {sol.steps.map((s, i) => <li key={i}>{s}</li>)}
                                    </ul>
                                </div>
                            ))}
                        </div>
                        <div className="text-center mt-12 border-t pt-8">
                            <h3 className="text-xl font-semibold mb-4">Da li je problem rešen?</h3>
                            <div className="flex justify-center gap-4">
                                <button onClick={() => alert('Drago nam je da smo pomogli!')} className="bg-green-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-green-700 transition duration-300">Da, hvala!</button>
                                <button onClick={() => onNeedFurtherHelp(`Problem sa uređajem '${selectedDevice}': ${problemDescription}`)} className="bg-red-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-red-600 transition duration-300">Ne, potrebna mi je dalja pomoć</button>
                            </div>
                        </div>
                         <div className="mt-8 flex justify-center">
                            <button onClick={() => setStep(2)} className="bg-gray-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-gray-600 transition duration-300">Nazad</button>
                         </div>
                    </div>
                );
        }
    };

    return (
        <section className="py-12 md:py-20">
            <div className="container mx-auto px-4">
                <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-8 md:p-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 font-montserrat text-blue-600">AI Asistent</h2>
                    <p className="text-center text-gray-600 mb-10">Opišite Vaš Problem</p>
                    <StepIndicator currentStep={step} />
                    <div className="mt-12">
                        {renderStepContent()}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Diagnostics;
import { GoogleGenAI, Type } from "@google/genai";
import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";

// Tipovi za parsiranje dolaznog zahteva
interface RequestBody {
    device: 'laptop' | 'tv' | 'ac' | 'washing-machine' | 'network' | 'other' | null;
    problemDescription: string;
}

// Proveravamo da li je API ključ postavljen u Netlify okruženju
if (!process.env.API_KEY) {
    throw new Error("GEMINI_API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Definišemo šemu koju očekujemo od API-ja
const schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: "Kratak, jasan naslov za predloženo rešenje (npr. 'Proverite napajanje')."
      },
      steps: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING
        },
        description: "Niz koraka koje korisnik treba da preduzme da bi primenio rešenje."
      }
    },
    required: ["title", "steps"]
  }
};

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            body: JSON.stringify({ error: 'Method Not Allowed' }),
        };
    }

    try {
        const { device, problemDescription } = JSON.parse(event.body || '{}') as RequestBody;

        if (!device || !problemDescription) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Uređaj i opis problema su obavezni.' }),
            };
        }

        const prompt = `
          Ti si AI asistent za servis elektronskih uređaja "Servis ELSINT DM". Ponašaj se kao iskusan i uslužan serviser.
          Korisnik ima problem sa uređajem.
          
          Uređaj: ${device}
          Opis problema: "${problemDescription}"
          
          Tvoj zadatak je da pružiš 3 konkretna, jednostavna i praktična rešenja koja korisnik može sam da isproba pre nego što donese uređaj u servis.
          Rešenja treba da budu formatirana kao JSON niz objekata, gde svaki objekat ima 'title' i 'steps' polja, u skladu sa priloženom šemom.
          Budi jasan, precizan i fokusiraj se na najčešće uzroke problema za dati uređaj i opis.
        `;
        
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
            },
        });
        
        const jsonText = response.text.trim();
        const solutions = JSON.parse(jsonText);

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(solutions),
        };

    } catch (error: any) {
        console.error("Greška u serverless funkciji:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Nismo uspeli da dobijemo dijagnostiku od AI asistenta. Došlo je do greške na serveru." }),
        };
    }
};

export { handler };
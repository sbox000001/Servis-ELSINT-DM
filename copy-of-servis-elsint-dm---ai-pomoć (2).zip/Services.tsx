import React from 'react';

const serviceItems = [
    {
        icon: 'fa-laptop-code',
        title: 'Popravka laptopova i računara',
        description: 'Rešavamo sve hardverske i softverske probleme, od zamene komponenti do čišćenja od virusa.'
    },
    {
        icon: 'fa-tv-alt',
        title: 'Servis televizora (LED, LCD)',
        description: 'Popravka svih vrsta kvarova na modernim televizorima, uključujući probleme sa slikom, zvukom i napajanjem.'
    },
    {
        icon: 'fa-fan',
        title: 'Dijagnostika i popravka klima',
        description: 'Servisiranje i popravka klima uređaja, dopuna freona i čišćenje sistema za optimalan rad.'
    },
    {
        icon: 'fa-blender-phone',
        title: 'Servis bele tehnike',
        description: 'Popravljamo veš mašine, frižidere, šporete i druge kućne aparate brzo i efikasno.'
    },
    {
        icon: 'fa-wifi',
        title: 'Mrežna oprema i instalacije',
        description: 'Podešavanje rutera, pojačivača signala i rešavanje problema sa internet konekcijom u vašem domu ili kancelariji.'
    },
    {
        icon: 'fa-microchip',
        title: 'Ostale elektronske popravke',
        description: 'Imate problem sa drugim elektronskim uređajem? Kontaktirajte nas da vidimo kako možemo pomoći.'
    }
];

const Services: React.FC = () => {
    return (
        <section id="services" className="py-20 bg-gray-50">
            <div className="container mx-auto px-4">
                <div className="text-center max-w-3xl mx-auto mb-16">
                    <h2 className="text-3xl md:text-4xl font-bold font-montserrat text-blue-600">Naše Usluge</h2>
                    <p className="text-lg text-gray-700 mt-4">Nudimo sveobuhvatne usluge popravke i održavanja za širok spektar elektronskih uređaja. Naš tim stručnjaka je opremljen najsavremenijom opremom za brzu i preciznu dijagnostiku i popravku.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {serviceItems.map((service, index) => (
                        <div key={index} className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col items-center text-center">
                            <div className="text-blue-500 text-5xl mb-4">
                                <i className={`fas ${service.icon}`}></i>
                            </div>
                            <h3 className="text-xl font-bold font-montserrat mb-3">{service.title}</h3>
                            <p className="text-gray-600 flex-grow">{service.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Services;
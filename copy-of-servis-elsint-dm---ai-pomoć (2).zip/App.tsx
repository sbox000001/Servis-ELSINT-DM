
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import Homepage from './components/Homepage';
import Diagnostics from './components/Diagnostics';
import Booking from './components/Booking';
import Services from './Services';
import Contact from './components/Contact';
import Footer from './components/Footer';

export type View = 'homepage' | 'services' | 'contact' | 'diagnostics' | 'booking';

const App: React.FC = () => {
    const [currentView, setCurrentView] = useState<View>('homepage');
    const [problemSummary, setProblemSummary] = useState('');

    const navigateTo = useCallback((view: View) => {
        setCurrentView(view);
        window.scrollTo(0, 0);
    }, []);

    const handleStartDiagnostics = useCallback(() => {
        navigateTo('diagnostics');
    }, [navigateTo]);

    const handleNeedFurtherHelp = useCallback((summary: string) => {
        setProblemSummary(summary);
        navigateTo('booking');
    }, [navigateTo]);
    
    const renderView = () => {
        switch (currentView) {
            case 'services':
                return <Services />;
            case 'contact':
                return <Contact />;
            case 'diagnostics':
                return <Diagnostics onNeedFurtherHelp={handleNeedFurtherHelp} />;
            case 'booking':
                return <Booking problemSummary={problemSummary} onBackToDiagnostics={() => navigateTo('diagnostics')} />;
            case 'homepage':
            default:
                return <Homepage onStartDiagnostics={handleStartDiagnostics} />;
        }
    };

    return (
        <div className="bg-gradient-to-br from-gray-100 to-gray-200 min-h-screen text-gray-800 font-sans flex flex-col">
            <Header onNavigate={navigateTo} />
            <main className="flex-grow">
                {renderView()}
            </main>
            <Footer onNavigate={navigateTo} />
        </div>
    );
};

export default App;

import React from 'react';

interface HomepageProps {
    onStartDiagnostics: () => void;
}

const Homepage: React.FC<HomepageProps> = ({ onStartDiagnostics }) => {
    return (
        <div>
            {/* Hero Section */}
            <section id="hero-homepage" className="relative bg-gradient-to-r from-blue-600 to-cyan-400 text-white text-center py-24 md:py-40 flex items-center justify-center min-h-[70vh] overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-full bg-black opacity-20"></div>
                <div className="container mx-auto px-4 z-10">
                    <div className="max-w-3xl mx-auto">
                        <h1 className="text-4xl md:text-6xl font-extrabold font-montserrat mb-4 leading-tight">Servis ELSINT DM</h1>
                        <p className="text-xl md:text-2xl mb-8 opacity-90">Koristimo naprednu AI Tehnologiju da brzo i efikasno dijagnostikujemo i rešimo probleme sa vašim uređajima.</p>
                        <button onClick={onStartDiagnostics} className="btn-gradient-animation text-blue-600 font-bold py-3 px-8 rounded-full text-lg transform hover:scale-105 shadow-lg">
                            Započnite Online Dijagnostiku
                        </button>
                    </div>
                </div>
            </section>

            {/* About Us Section */}
            <section id="about" className="py-20 bg-white">
                <div className="container mx-auto px-4 max-w-4xl">
                    <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-montserrat text-blue-600">O Nama</h2>
                    <p className="text-lg text-gray-700 mb-6">Servis ELSINT DM je osnovan sa vizijom pružanja vrhunskih usluga popravke elektronskih uređaja, koristeći inovativne pristupe i naprednu tehnologiju. Naša misija je da budemo vaš pouzdan partner u održavanju i rešavanju problema sa elektronikom, štedeći vam vreme i novac.</p>
                    <p className="text-lg text-gray-700 mb-6">Sa godinama iskustva u industriji, izgradili smo tim posvećenih i sertifikovanih tehničara koji su strastveni u onome što rade. Verujemo u transparentnost, kvalitet i zadovoljstvo klijenata.</p>
                    <p className="text-lg text-gray-700">Ponosimo se našim AI Asistentom, pametnim alatom koji vam omogućava da brzo dijagnostikujete problem i dobijete predložena rešenja pre nego što čak i donesete uređaj u servis. U Servisu ELSINT DM, tehnologija služi vama.</p>
                </div>
            </section>

            {/* How It Works Section */}
            <section id="how-it-works" className="py-20 bg-gray-50">
                <div className="container mx-auto px-4 max-w-5xl">
                    <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-montserrat text-blue-600">Kako Funkcioniše?</h2>
                    <div className="grid md:grid-cols-3 gap-8 text-center">
                        {/* Step 1 */}
                        <div className="flex flex-col items-center">
                            <div className="bg-blue-600 text-white rounded-full w-20 h-20 flex items-center justify-center text-3xl mb-4 shadow-lg">
                                <i className="fas fa-comment-dots"></i>
                            </div>
                            <h3 className="text-xl font-bold mb-2 font-montserrat">1. Opišite Problem</h3>
                            <p className="text-gray-600">Koristite našeg AI Asistenta da detaljno opišete problem sa vašim uređajem.</p>
                        </div>
                        {/* Step 2 */}
                        <div className="flex flex-col items-center">
                            <div className="bg-blue-600 text-white rounded-full w-20 h-20 flex items-center justify-center text-3xl mb-4 shadow-lg">
                                <i className="fas fa-lightbulb"></i>
                            </div>
                            <h3 className="text-xl font-bold mb-2 font-montserrat">2. Dobijte Rešenja</h3>
                            <p className="text-gray-600">Naš pametni sistem će vam odmah ponuditi moguća rešenja koja možete sami isprobati.</p>
                        </div>
                        {/* Step 3 */}
                        <div className="flex flex-col items-center">
                            <div className="bg-blue-600 text-white rounded-full w-20 h-20 flex items-center justify-center text-3xl mb-4 shadow-lg">
                                <i className="fas fa-calendar-check"></i>
                            </div>
                            <h3 className="text-xl font-bold mb-2 font-montserrat">3. Zakažite Servis</h3>
                            <p className="text-gray-600">Ako problem i dalje postoji, lako zakažite dolazak naših tehničara ili telefonski poziv.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Why Choose Us Section */}
            <section id="why-us" className="py-20 bg-white">
                <div className="container mx-auto px-4 max-w-5xl">
                    <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-montserrat text-blue-600">Zašto Izabrati Nas?</h2>
                    <div className="grid md:grid-cols-3 gap-8">
                        <div className="bg-gray-50 p-8 rounded-lg shadow-md text-center hover:shadow-xl transition-shadow duration-300">
                            <i className="fas fa-robot text-4xl text-blue-500 mb-4"></i>
                            <h3 className="text-xl font-bold mb-2 font-montserrat">Pametna AI Dijagnostika</h3>
                            <p className="text-gray-600">Uštedite vreme i novac uz našu brzu i preciznu online dijagnostiku problema.</p>
                        </div>
                        <div className="bg-gray-50 p-8 rounded-lg shadow-md text-center hover:shadow-xl transition-shadow duration-300">
                            <i className="fas fa-user-cog text-4xl text-blue-500 mb-4"></i>
                            <h3 className="text-xl font-bold mb-2 font-montserrat">Iskusni Tehničari</h3>
                            <p className="text-gray-600">Naš tim čine sertifikovani stručnjaci sa višegodišnjim iskustvom u popravkama.</p>
                        </div>
                        <div className="bg-gray-50 p-8 rounded-lg shadow-md text-center hover:shadow-xl transition-shadow duration-300">
                            <i className="fas fa-shipping-fast text-4xl text-blue-500 mb-4"></i>
                            <h3 className="text-xl font-bold mb-2 font-montserrat">Brza i Pouzdana Usluga</h3>
                            <p className="text-gray-600">Garantujemo efikasnu popravku i transparentnu komunikaciju tokom celog procesa.</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Homepage;